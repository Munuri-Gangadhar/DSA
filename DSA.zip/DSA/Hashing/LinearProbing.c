#include<stdio.h>
#include<stdlib.h>
#define size 10
int a[size];
void initialize();
void insert();
void traverse();
void deletion();
int main(){
    initialize();
    int op;
    while(1){
       printf("Enter the operation");
       scanf("%d",&op);
       switch(op){
           case 1:
           insert();
           break;
           case 2:
           traverse();
           break;
           default:
           exit(0);
           break;
       }
    }
}

void initialize(){
   for(int i=0;i<size;i++){
      a[i]=-1;
   }
}
void insert(){
    int i,hkey,value;
    printf("Enter the value:");
    scanf("%d",&value);
    hkey=value%size;
   for(i=0;i<size;i++){
        if(a[hkey+i]%size==-1){
            a[hkey+i]=value;
            break;
        }
   }
   if(i==size){
      printf("No free slot available");
   }

}
void traverse(){
    int i;
    for(i=0;i<size;i++){
        if(a[i]==-1)
        printf("slot is element");
        else{
            printf("%d",a[i]);
        }
    }
}
void deletion(){
    int value,hkey,i;
    printf("Enter the value");
    scanf("%d",&value);
    hkey=value%size;
    for(i=0;i<size;i++){
        if(a[hkey+i]%size==value){
            a[hkey+i]=-1;
            break;
        }
    }
    if(i==size){
        printf("value is not found");
    }
}