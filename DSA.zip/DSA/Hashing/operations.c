#include<stdio.h>
#include<stdlib.h>
#define size 5
struct node{
    int data;
    struct node *next;
}*temp,*p;
int a[size];
void create(){
   int hkey,value;
   temp=(struct node*)malloc(sizeof(struct node));
   printf("enter the value");
   scanf("%d",&value);
   hkey=value%size;
   temp->data=value;
   temp->next=NULL;
   if(a[hkey]==NULL){
      a[hkey]=temp;
   }
   else{
      p=a[hkey];
      while(p->next!=NULL){
          p=p->next;
      }
      p->next=temp;
   }
}
void intialise(){
    for(int i=0;i<size;i++){
        a[i]=NULL;
    }
}
void del(){
    int value,hkey;
    printf("enter the element to delete");
    scanf("%d",&value);
    p=a[hkey];
   if(a[hkey]==NULL){
      printf("chain is empty");
   }
   else if(p->next==NULL){
      if(p->data==value){
         temp=p;
         a[hkey]=NULL;
         free(temp);
      }
   }
   else{
       if(p->data==value){
            temp=p;
            a[hkey]=p->next;
            temp->next=NULL;
            free(temp);
       }
       while(p!=NULL){
        if(p->next->data==value){
            temp=p->next;
            p->next=temp->next;
            temp->next=NULL;
            free(temp);
        }
        else{
            p=p->next;
        }
       }
   }
    
}
void traverse(){
    for(int i=0;i<size;i++){
        p=a[i];
        if(p==NULL){
            printf("chain is empty");
        }
        else{
            while(p!=NULL){
                printf("%d\n",p->data);
                p=p->next;
            }
        }
    }
}
void search(){
    int value,hkey,flag=0;
    printf("enter the data to search");
    scanf("%d",&value);
    hkey=value%size;
    p=a[hkey];
    while(p!=NULL){
        if(p->data==value)
           flag=1;
        p=p->next;
    }
    if(flag==0){
        printf("Element is not found");
    }
    else{
        printf("Element is found");
    }
}
int main(){
    int op;
    intialise();
    while(1){
        printf("enter the operation");
        scanf("%d",&op);
        switch(op){
            case 1:
            create();
            break;
            case 2:
            del();
            break;
            case 3:
            traverse();
            break;
            case 4:
            search();
            break;
            default:
            exit(0);
            break;
        }
    }
}