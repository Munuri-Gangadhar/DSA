#include<stdio.h>
#include<stdlib.h>
int HT[100],size;
void insert(int arr[],int size){
    for(int i=0;i<size;i++){
        printf("Enter the element");
        scanf("%d",&arr[i]);
    }
}
void maxheap(int a[],int x){
    for(int i=x/2-1;i>=0;i--){
          max_heapify(a,x,i);
    }
}
void max_heapify(int a[],int n,int i){
    int largest,r,l;
    largest=i;
    l=2*i+1;
    r=2*i+2;
    if(l<n && a[l]>a[largest]){
        largest=l;
    }
    if(r<n && a[r]>a[largest]){
        largest=r;
    }
    if(largest!=i){
        swap(i,largest);
        max_heapify(a,n,largest);
    }
}
void minheap(int a[],int x){
    for(int i=x/2-1;i>=0;i--){
          min_heapify(a,x,i);
    }
}

void min_heapify(int a[],int n,int i){
    int smallest,r,l;
    smallest=i;
    l=2*i+1;
    r=2*i+2;
    if(l<n && a[l]<a[smallest]){
        smallest=l;
    }
    if(r<n && a[r]<a[smallest]){
        smallest=r;
    }
    if(smallest!=i){
        swap(i,smallest);
        min_heapify(a,n,smallest);
    }
}
void swap(int a,int b){
   int temp=HT[a];
   HT[a]=HT[b];
   HT[b]=temp;
}
void traverse(int arr[],int size){
   for(int i=0;i<size;i++){
        printf("%d\t",arr[i]);
   }
}

void Max_sort(int a[],int n){
    for(int i=n/2-1;i>=0;i--){
        min_heapify(a,n,i);
    }
    for(int i=n-1;i>=0;i--){
        swap(0,i);
        // max_heapify(a,n,i);
        min_heapify(a,i,0);
    }
}

void Min_sort(int a[],int n){
    for(int i=n/2-1;i>=0;i--){
        max_heapify(a,n,i);
    }
    for(int i=n-1;i>=0;i--){
        swap(0,i);
        // max_heapify(a,n,i);
        max_heapify(a,i,0);
    }
}
int main(){
    while(1){
        int op;
        printf("1.Insert\n2.Max_heap\n3.Min_heap\n4.Maxheapsort\n5.Minheapsort\n6.Traverse");
        printf("\nenter the operation:");
        scanf("%d",&op);
        switch(op){
            case 1:
            printf("\nEnter no.of elements:");
            scanf("%d",&size);
            insert(HT,size);
            break;
            case 2:
            maxheap(HT,size);
            break;
            case 3:
            minheap(HT,size);
            break;
            case 4:
            Max_sort(HT,size);
            break;
            case 5:
            Min_sort(HT,size);
            break;
            case 6:
            traverse(HT,size);
            break;
            default:
            exit(0);
            break;
        }
    }
}