#include<stdio.h>
#include<stdlib.h>
#define max 5
int CQ[max],front=-1,rear=-1;
void ENQUEUE();
void traverse();
void DEQUEUE();
void peek();
int main(){
    int op;
    printf("1.Enqueue\n2.Traverse\n3.Dequeue\n4.Peek");
    while(1){
        printf("\nEnter your option");
        scanf("%d",&op);
        switch(op){
            case 1:
            ENQUEUE();
            break;
            case 2:
            traverse();
            break;
            case 3:
            DEQUEUE();
            break;
            case 4:
            peek();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void ENQUEUE(){
   int val;
   if(front==(rear+1)%max){
    printf("QUEUE IS FULL\n");
   }
   else{
        printf("enter the value:");
        scanf("%d",&val);
        rear=(rear+1)%max;
        CQ[rear]=val;
   }
   if(rear==0){
       front=0;
   }
}
void traverse(){
    int i;
    if(rear>=front){
        for(i=front;i<=rear;i++){
            printf("%d\n",CQ[i]);
        }
    }
    else{
        for(i=front;i<=max-1;i++){
            printf("%d\n",CQ[i]);
        }
        for(i=0;i<=rear;i++){
            printf("%d\n",CQ[i]);
        }
    }
}
void DEQUEUE(){
    if(front==-1){
        printf("QUEUE is empty");
    }
    else{
        printf("%d",CQ[front]);
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else{
            front=(front+1)%max;
        }
    }
}
void peek(){
    if(rear==-1){
        printf("No elements is front"); 
    }
    else{
        printf("%d\n",CQ[front]);
    }
}

