#include<stdio.h>
#include<stdlib.h>
int main(){
    int arr[100]={3,4,1,3,512,34341,3413,1,2,3,2};
    int i,ele,j=0;
    printf("Enter the element");
    scanf("%d",&ele);
    for(i=1;i<=sizeof(arr);i++){
        if(ele==arr[i])
        break;
    }
    printf("Element%d is found at%d",ele,i);

    
}