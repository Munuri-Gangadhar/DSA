#include<stdio.h>
int arr[6];
int main(){
    int i,j;
    for(i=0;i<10;i++){
        printf("Enter the elements");
        scanf("%d",&arr[i]);
    }
    for(i=0;i<10;i++){
       printf("%d\t",arr[i]);
    }
    //insertion sort logic goes here
    int key;
    for(i=1;i<10;i++){
        key=arr[i];
        for(j=i-1;j>=0 && arr[j]>key ;j--){
            arr[j+1]=arr[j];
        }
        arr[j+1]=key;
    }
    printf("\n");
    for(i=0;i<10;i++){
       printf("%d\t",arr[i]);
    }

}