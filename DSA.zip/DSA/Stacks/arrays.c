#include <stdio.h> 
int stack[5],i,n,j,choice=0,top=-1;  
void push(){  
    int a;      
    if(top==n-1)   
    printf("\n Overflow");   
    else {  
        printf("Enter the value:");  
        scanf("%d",&a);         
        top=top+1;   
        stack[top]=a;   
    }   
}   
  
void pop(){   
    if(top==-1)   
    printf("Underflow");  
    else  
    top = top -1;   
}   
void peek(){  
    if(top==-1){  
        printf("Stack is empty");  
    } 
    else{
        printf("%d",stack[top]);
    } 
}
void traverse(){
    if(top==-1){
        printf("stack is underflow");
    }
    else{
        for(i=top;i>=0;i--){
            printf("%d\t",stack[i]);
        }
    }
}
 
void main(){  
      
    printf("Enter the number of elements in the stack:");   
    scanf("%d",&n);  
    while(choice!=5)  
    {    
        printf("\n1.Push\n2.Pop\n3.peek\n4.traverse\n5.Exit"); 

        printf("\n Enter your choice:");        
        scanf("%d",&choice);  
        switch(choice)  
        {  
            case 1:   
                push();  
                break;              
            case 2:    
                pop();  
                break;   
            case 3:               
                peek();  
                break; 
            case 4: 
                traverse();
                break;                  
            case 5:       
                break;    
            default:  
              printf("Please Enter valid choice ");  
            }; 
        }  
    }