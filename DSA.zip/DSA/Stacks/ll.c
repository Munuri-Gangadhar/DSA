#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*top=NULL,*p,*temp;
void push();
void pop();
void traverse();
void peek();
int main(){
    int op;
    while(1){
        printf("\nenter the option");
        scanf("%d",&op);
        switch(op){
            case 1:
            push();
            break;
            case 2:
            pop();
            break;
            case 3:
            traverse();
            break;
            case 4:
            peek();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void push(){
    int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data");
    scanf("%d",&data);
    temp->data=data;
    temp->next=NULL;
    if(top==NULL){
        top=temp;
    }
    else{
        temp->next=top;
        top=temp;
    }
}
void traverse(){
    p=top;
    if(top==NULL){
        printf("list is empty");
    }
    else{
        while(p!=NULL){
            printf("%d\n",p->data);
            p=p->next;
        }
    }
}
void pop(){
    if(top==NULL){
        printf("list is empty");
    }
    else{
        temp=top;
        top=top->next;
        temp->next=NULL;
        free(temp);
    }
}
void peek(){
    if(top==NULL){
        printf("list is empty");
    }
    else{
        printf("peek data is :%d",top->data);
    }
}