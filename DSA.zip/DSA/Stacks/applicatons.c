#include<stdio.h>
#include<stdlib.h>
#define size 10
int top=-1;
int main(){
    int n,i;
    printf("enter the number:");
    scanf("%d",&n);
    int fact[n],fa=1;
    //Entering the elements
    for(i=1;i<=n;i++){
        top=top+1;
        fact[top]=i;
    }
    //printing the values8
    for(i=top;i>=0;i--){
        printf("%d\n",fact[i]);
    }
    //finding the factorial of the given number
    for(i=1;i<=n;i++){
        fa=fa*fact[top];
        top=top-1;
    }
    
    printf("The factorial of %d is :%d",n,fa);
}