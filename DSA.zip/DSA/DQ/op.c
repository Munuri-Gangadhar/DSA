#include<stdio.h>
#include<stdlib.h>
#define max 5
int DQ[max],front=-1,rear=-1;
void Rear_Insert();
void traverse();
void Front_Del();
void Rear_Del();
void Front_Insert();
int main(){
    int op;
    printf("1.Insertion through rear\n2.Deletion through front\n3.Deletion through rear\n4.Insertion through front\n5.Traverse");
    while(1){
        printf("\nEnter your option:");
        scanf("%d",&op);
        switch(op){
            case 1:
            Rear_Insert();
            break;
            case 2:
            Front_Del();
            break;
            case 3:
            Rear_Del();
            break;
            case 4:
            Front_Insert();
            break;
            case 5:
            traverse();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void Rear_Insert(){
    int ele;
    if(rear==max-1){
        printf("Queue is full\n");
    }
    else{
        rear=rear+1;
        printf("enter the element:");
        scanf("%d",&ele);
        DQ[rear]=ele;
    }
    if(rear==0){
       front=0;
    }
}
void traverse(){
    int i;
    if(rear>=front){
        for(i=front;i<=rear;i++){
            printf("%d\n",DQ[i]);
        }
    }
    else{
        for(i=front;i<=max-1;i++){
            printf("%d\n",DQ[i]);
        }
        for(i=0;i<=rear;i++){
            printf("%d\n",DQ[i]);
        }
    }
}
void Front_Del(){
   if(rear==-1){
        printf("\nQueue is empty");
    }
    else{
        printf("Deleted element:");
        printf("%d\n",DQ[front]);
        front=front+1;
        if(front==rear);
    }
}

void Rear_Del(){
   if(front==-1){
    printf("queue is underflow");
   }
   else{
     if(front==rear){
          front=-1;
          rear=-1;
     }
     else{
        printf("The deleting element is%d ",DQ[rear]);
        rear=rear-1;
     }
   }
}
void Front_Insert(){
   if(front<=0){
      printf("Insertion is not possible at front end");
   }
   else{
      int data;
      printf("enter the data");
      scanf("%d",&data);
      front=front-1;
      DQ[front]=data;
   }
}

