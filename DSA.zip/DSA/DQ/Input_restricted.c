#include<stdio.h>
#include<stdlib.h>
#define max 5
int DQ[max],front=-1,rear=-1;
void Rear_Insert();
void traverse();
void Front_Del();
void Rear_Del();
// void Front_Insert();
int main(){
    int op;
    printf("1.Insertion through beginning\n2.Deletion at beginning 3.Deletion at ending\n4.Traverse");
    while(1){
        printf("\nEnter your option:");
        scanf("%d",&op);
        switch(op){
            case 1:
            Rear_Insert();
            break;
            case 2:
            Front_Del();
            break;
            case 3:
            Rear_Del();
            break;
            case 4:
            traverse();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void Rear_Insert(){
   int val;
   if(front==(rear+1)%max){
    printf("QUEUE IS FULL\n");
   }
   else{
        printf("enter the value:");
        scanf("%d",&val);
        rear=(rear+1)%max;
        DQ[rear]=val;
   }
   if(rear==0){
       front=0;
   }
}
void traverse(){
    int i;
    if(rear>=front){
        for(i=front;i<=rear;i++){
            printf("%d\n",DQ[i]);
        }
    }
    else{
        for(i=front;i<=max-1;i++){
            printf("%d\n",DQ[i]);
        }
        for(i=0;i<=rear;i++){
            printf("%d\n",DQ[i]);
        }
    }
}
void Front_Del(){
    if(front==-1){
        printf("QUEUE is empty");
    }
    else{
        printf("%d",DQ[front]);
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else{
            front=(front+1)%max;
        }
    }

}
void Rear_Del(){
    if(front==-1){
        printf("queue is underflow");
    }
    else{
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else{
            printf("%d",DQ[rear]);
            rear=rear-1;
        }
    }
}
