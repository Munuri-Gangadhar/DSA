#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};
int main(){
    struct node *head,*first,*second,*third;
    head=(struct node*)malloc(sizeof(struct node));
    first=(struct node*)malloc(sizeof(struct node));
    second=(struct node*)malloc(sizeof(struct node));
    third=(struct node*)malloc(sizeof(struct node));
   
   //we have to link the nodes
   head=first;
   first->next=second;
   second->next=third;
   third->next=NULL;
    
struct node *p;
  p=(struct node*)malloc(sizeof(struct node));
//giving the user input data to the nodes
p=head;
while(p!=NULL){
    printf("enter the data");
    scanf("%d",&p->next);
    p=p->next;
}
int i=1;
while(p!=NULL){
    printf("The data of %d is %d",i,p->next);
    p=p->next;
    i++;
}

}