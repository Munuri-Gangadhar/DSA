#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*start,*temp,*p,*start1,*start2;
struct node *creation(struct node *p){
    int n,i;
    printf("Enter the no.of nodes");
    scanf("%d",&n);
    for(i=0;i<n;i++){
    int m;
    p=(struct node*)malloc(sizeof(struct node));
    printf("enter the data");
    scanf("%d",&m);
    p->data=m;
    p->next=NULL;
    if(p==NULL){
       start=temp;
       p=temp;
    }
    else{
       p->next=temp;
       p=temp;
      }
    }
}
struct node*concate(struct node *p,struct node *start2){
    p=start1;
    while(p->next!=NULL){
    p=p->next;
    }
    p->next=start2;
}
void traverse(struct node *pr){
    
}
int main(){
    while(1){
        int n;
        printf("Enter the node");
        switch(n){
            case 1:
            start1=creation(start1);
            start2=creation(start2);  
            concate(start1,start2);
            case 2:
        
            
        }
    } 
}