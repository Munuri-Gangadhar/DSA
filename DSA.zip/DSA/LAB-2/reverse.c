#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};
struct node* reverse(struct node *head){
   struct node *temp,*temp2;
     temp=NULL;
    temp2=NULL;
    while(head!=NULL){
        temp2=head->next;
        head->next=temp;
        temp=head;
        head=temp2;
    }
    head=temp;
    return head;
}
int main(){
    struct node *head,*first,*second,*third,*fourth,*p;
    head=(struct node*)malloc(sizeof(struct node));
    first=(struct node*)malloc(sizeof(struct node));
    second=(struct node*)malloc(sizeof(struct node));
    third=(struct node*)malloc(sizeof(struct node));
    fourth=(struct node*)malloc(sizeof(struct node));
    // temp=(struct node*)malloc(sizeof(struct node));
    // temp2=(struct node*)malloc(sizeof(struct node));

//assigning the data
   
  
    //linking the nodes
    head=first;
    first->next=second;
    second->next=third;
    third->next=fourth;
    fourth->next=NULL;
     
    first->data=10;
    second->data=20;
    third->data=30;
    fourth->data=40;

    p=reverse(head);
    while(p!=NULL){
        printf("%d\n",p->data);
        p=p->next;
    }
}