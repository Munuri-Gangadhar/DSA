   #include<stdio.h>
   #include<stdlib.h>
   struct node{
      int data;
      struct node *next;
   }*start,*temp,*p,*start1,*start2,*k;
   struct node *creation(struct node *p);
   void print(struct node *k);
   int main(){ 
      start1=creation(start1);
      start2=creation(start2);
      p=start1;
      while(p->next!=NULL){
      p=p->next;
      }
      p->next=start2;

      p=start1;
      while(p!=NULL){
         printf("%d\n",p->data);
         p=p->next;
      }
      return 0;  
   }
   struct node *creation(struct node *start){
      int n,i;
      printf("Enter the no.of nodes");
      scanf("%d",&n);
      for(i=0;i<n;i++){
      int m;
      temp=(struct node*)malloc(sizeof(struct node));
      printf("enter the data");
      scanf("%d",&m);
      temp->data=m;
      temp->next=NULL;
      if(start==NULL){
         start=temp;
         p=temp;
      }
      else{
         p->next=temp;
         p=temp;
         }
      }
      return start;
   }
  

