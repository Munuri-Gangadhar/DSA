#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*start=NULL,*temp,*p,*temp1,*temp2,*newnode=NULL;
void create();
void traverse();
void insert_start();
void insert_end();
void insert_pos();
void delete_start();
void delete_end();
void delete_pos();
void reverse();
void search();
void sort();
void conca();
struct node*creation(struct node*newnode);
int main(){  
    int n;
    printf("\n 1.Create \n 2.Traverse \n 3.Insert at start \n 4.Insert at end\n 5.Insert at specified postion \n 6.Delete at start \n 7.Delete at end \n 8.Delete at specified position\n 9.Reverse a list\n 10.Search an element \n 11.Sorting \n12.Concatenation\n");
    printf("Enter the option:");
    scanf("%d",&n);
    while(n!=-1){
    switch(n){
        case 1:
        create();
        break;
        case 2:
        traverse();
        break;
        case 3:
        insert_start();
        break;
        case 4:
        insert_end();
        break;
        case 5:
        insert_pos();
        break;
        case 6:
        delete_start();
        break;
        case 7:
        delete_end();
        break;
        case 8:
        delete_pos();
        break;
        case 9:
        reverse();
        break;
        case 10:
        search();
        break;
        case 11:
        sort();
        break;
        case 12:
        conca();
        break;
        default:
        printf("you have entered the other value");
        break;
    }
    // printf("\n 1.Create \n 2.Traverse \n 3.Insert at start \n 4.Insert at end\n 5.Insert at specified postion \n 6.Delete at start \n 7.Delete at end \n 8.Delete at specified position\n 9.Reverse a list\n 10.Search an element \n 11.Sorting \n");
    printf("\nEnter option:");
    scanf("%d",&n);
    
}
return 0;

}
void create(){
    int n,i;
    printf("Enter the no.of nodes");
    scanf("%d",&n);
    for(i=0;i<n;i++){
    int m;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data");
    scanf("%d",&m);
    temp->data=m;
    temp->next=NULL;
    if(start==NULL){
       start=temp;
       p=temp;
    }
    else{
       p->next=temp;
       p=temp;
    }
}
 printf("succesfully created\n");
 traverse();
}

void traverse(){
if(start==NULL){
      printf("no data is present");
}
else{
    p=start;
    while(p!=NULL){
        printf("%d\n",p->data);
        p=p->next;
    }
}
}
void insert_start(){
   temp=(struct node*)malloc(sizeof(struct node));
   int x;
   printf("Enter the data");
   scanf("%d",&x);
   temp->data=x;
   temp->next=NULL;
   if(start==NULL){
     start=temp;
   }
   else{
      temp->next=start;
      start=temp;
   }
   traverse();
}
void insert_end(){
    temp=(struct node*)malloc(sizeof(struct node));
    int k;
    printf("enter the data");
    scanf("%d",&k);
    temp->data=k;
    temp->next=NULL;
    if(start==NULL){
        start=temp;
    }
    else{
        p=start;
        while(p->next!=NULL){
            p=p->next;
        }
        p->next=temp;
    }  
    traverse(); 
}
void insert_pos(){
    int pos,i,count=1,val;
    p=start;
    while(p!=NULL){
        p=p->next;
        count=count+1;
    }
    printf("Enter the position");
    scanf("%d",&pos);
    if(pos==1){
        insert_start();  
}
    else if(pos==count+1){
        insert_end();
 }
    else if(pos>1 && pos<count+1){
    printf("Enter the data");
    scanf("%d",&val);
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=val;
    temp->next=NULL;
        p=start;
        for(i=1;i<pos-1;i++){
                 p=p->next;   
        }
        temp->next=p->next;
        p->next=temp;
}   else{
    printf("Entered invalied statement\n");
}
    traverse();
    }
void delete_start(){
    if(start==NULL){
        printf("list is empty");
    }
    else if(start->next==NULL){
          temp=start;
          start=start->next;
          free(temp);      
    }
    else{
        p=start;
        start=start->next;
        p->next=NULL;
        free(p);
    }
    printf("successfully deleted at start\n");
    traverse();
}
void delete_end(){
    if(start==NULL){
         printf("list is empty");
    }
    else if(start->next==NULL){
          temp=start;
          start=start->next;
          free(temp);      
    }
    else{
        p=start;
        while(p->next->next!=NULL){
            p=p->next;
        }
        temp=p->next;
        p->next=NULL;
        free(temp);
    }
    printf("successfully deleted at end\n");
    traverse();
}
void delete_pos(){
    p=start;
    int count=0,pos,i;
    while(p!=NULL){
        p=p->next;
        count++;  
    }
    printf("Enter position to delete:");
    scanf("%d",&pos);
    if(pos==1){
    delete_start(); 
}
   else if(pos==count+1){
    delete_end();
   }
   else if(pos>1 && pos<count+1){
     p=start;
    for(i=1;i<pos-1;i++){
       p=p->next;
    }
    temp=p->next;
    p->next=temp->next;
    temp->next=NULL;
    free(temp);
   }
   else{
    printf("invalied position");
   }
}

void reverse(){
   struct node *temp,*temp2;
    temp=NULL;
    temp2=NULL;
    while(start!=NULL){
        temp2=start->next;
        start->next=temp;
        temp=start;
        start=temp2;
    }
    start=temp;
    p=start;
    printf("Reversed lists\n");
    while(p!=NULL){
        printf("%d\n",p->data);
        p=p->next;
    }
}
void search(){
    if(start==NULL){
        printf("linkelist is empty");
    }
    else{
        int x;
        printf("enter the element to search:");
        scanf("%d",&x);
        p=start;
        int flag=0,index=1;
        while(p!=NULL){
            if(p->data==x){ 
            flag=1;
            break;
        }  
            index=index+1;
            p=p->next;
        }
        if(flag==0){
            printf("Searching element is not found");
        }
        else{
            printf("Searching Element is found at:%d",index);
        }
    }
}
void sort(){
   p=start;
   if(start==NULL){
    printf("list is empty");
   }
   else{
    int x;
     for(temp1=p;temp1!=NULL;temp1=temp1->next){
        for(temp2=temp1->next;temp2!=NULL;temp2=temp2->next){
            if(temp1->data>temp2->data){
                 x=temp1->data;
                 temp1->data=temp2->data;
                 temp2->data=x;
            }
        }
     }

   }
   traverse();
}
struct node*creation(struct node *newnode){
  struct node *k;
      int n,i;
      printf("Enter the no.of nodes");
      scanf("%d",&n);
      for(i=0;i<n;i++){
      int m;
      temp=(struct node*)malloc(sizeof(struct node));
      printf("enter the data");
      scanf("%d",&m);
      temp->data=m;
      temp->next=NULL;
      if(newnode==NULL){
         newnode=temp;
         k=temp;
      }
      else{
         k->next=temp;
         k=temp;
         }
      }
    return newnode;
}
void conca(){
      newnode=creation(newnode);
      //entered node
      printf("entered node\n");
      p=newnode;
      while(p!=NULL){
        printf("%d",p->data);
        p=p->next;
      }
      p=start;
      while(p->next!=NULL){
        p=p->next;
      }
      p->next=newnode;
      
      traverse();

}
  
