#include<stdio.h>
#include<stdlib.h>
 struct node{
    int data;
    struct node *next;
}*start,*p,*temp;
void createlist(int n);
void display();
int main(){
    int n;
    printf("enter no.of nodes");
    scanf("%d",&n);
    createlist(n);
    printf("The traverse of the list is \n");
    display();
   } 

void createlist(int n){
    int i;
   for(i=0;i<n;i++){
    temp=(struct node*)malloc(sizeof(struct node));
    temp->next=NULL;
    printf("enter the data for the node");
    scanf("%d",&temp->data);
    if(start==NULL){
        start=temp;
        p=start;
    }
    else{
       p->next=temp;
       p=temp;
    }
}
   printf("successfully created\n");
}

void display(){
   struct node *ptr;
   if(start==NULL){
    printf("the list is empty");
   }
   else{
   ptr=start;
   while(ptr!=NULL){
        printf("%d\n",ptr->data);
        ptr=ptr->next;
   }

}
}