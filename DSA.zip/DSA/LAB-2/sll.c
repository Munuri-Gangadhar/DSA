#include<stdio.h>
#include<stdlib.h>
struct node{

};
int main(){
    
}