#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int itemcount=0,pq[MAX];
void insert();
void delete();
void traverse();
void main(){
    int m;
    printf("Choose an option from below:\n");
    printf("Enter-1 to insert\n");
    printf("Enter-2 to delete\n");
    printf("Enter-3 to traverse\n");
    printf("Enter-4 to exit\n");
    do{ 
        printf("Enter your choice:");
        scanf("%d",&m);
        switch(m){
             case 1:insert();
                    break;
             case 2:delete();
                   break;
             case 3:traverse();
                    break;
             case 4:exit(0);
        }
    }while(m!=4);
}
int isFull()
{   
    return itemcount==MAX;
}
void insert(){
    int i,x;
    if(!isFull())
    { 
    printf("Enter the data to insert:");
    scanf("%d",&x);
        if(itemcount==0)
	    {
            pq[itemcount++]=x;
	    }
	    else
	    {
            for(i=itemcount-1;i>=0;i--)
	        { 
                if(x>pq[i])
		        { 
                    pq[i+1]=pq[i];
		        }
		        else
		        {
                     break;
		        }
	        }
	        pq[i+1]=x;
	        itemcount=itemcount+1;
	    }
    }
    else{
        printf("\nqueue is overflow\n");
    }    
}
void delete()
{ 
    if(itemcount==0)
    { 
        printf("Queue is empty\n");
    }    
    else
    { 
        printf("Deleting element is %d\n",pq[--itemcount]);
    }    
}    
void traverse()
{ 
   // int i=0;
    if(itemcount==0)
    {
 	    printf("Queue is underflowed\n");
    }
    for(int i=itemcount-1;i>=0;i--)
    {
        printf("%d ",pq[i]);
    }
    printf("\n");
}