//seperate chaining
#include<stdio.h>
#include<stdlib.h>
#define SIZE 5
struct node{
    int data;
    struct node*next;
}*temp,*p;
struct node*arr[5];    
void insertion();
void deletion();
void traverse();
void search();
void main(){
    for(int i=0;i<5;i++){
       arr[i]=NULL;
    }
    int m;
    printf("Menu:\n");
    printf("1.insertion\n");
    printf("2.deletion\n");
    printf("3.traverse\n");
    printf("4.search\n");
    printf("5.Exit\n");
    printf("-------------------\n");
    do{
       printf("\nenter which operation u want:");
       scanf("%d",&m);
       switch(m){
       case 1:insertion();
              break;
       case 2:deletion();
              break;
       case 3:traverse();
              break;
       case 4:search();
              break;
       case 5:exit(0);
       }
    }while(m!=5);
}
void insertion(){
    temp=(struct node*)malloc(sizeof(struct node));
    int value,hkey;
    printf("Enter the value to insert:");
    scanf("%d",&value);
    hkey=value%5;
    temp->data=value;
    temp->next=NULL;
    if(arr[hkey]==NULL){
        arr[hkey]=temp;
    }
    else{
        p=arr[hkey];
        while(p->next!=NULL){
            p=p->next;
        }
        p->next=temp;
    }  
}
void deletion(){
     int value;
     printf("Enter value to delete:");
     scanf("%d",&value);
     int hkey;
     hkey=value%5;
     p=arr[hkey];
     if(p==NULL){
        printf("Bucket is empty");
     }
     else if(p->next==NULL){
        if(p->data==value){
            temp=p;
            arr[hkey]=NULL;
            free(temp);
        }
     }
     else{
        if(p->data==value){
          temp=p;
          arr[hkey]=p->next;
          temp->next=NULL;
           free(temp);
        }
        else{
        while(p!=NULL){
            if(p->next->data==value){
                temp=p->next;
                p->next=temp->next;
                temp->next=NULL;
                free(temp);
            }
            else{
                p=p->next;
            }
        }
        }
     }
    printf("\n");
}
void traverse(){
      for(int i=0;i<5;i++){
        p=arr[i];
        if(p==NULL){
            printf("\nBucket %d is empty",i);
        }
        else{
            while(p!=NULL){
                printf("\nBucket-%d contains %d",i,p->data); 
                p=p->next;
            }
        }
      }
}
void search(){
    int hkey,found=0,value;
    printf("Enter the value you want to search:");
    scanf(" %d",&value);
    hkey=value%5;
    p=arr[hkey];
    while(p!=NULL){
        if(value==p->data){
            found=1;
            break;
            }
            p=p->next;
    }
    if(found==1){
        printf("The value-%d is found at bucket-%d\n",value,hkey);
    }
    else{
        printf("The value-%d is not found\n",value);
    }
}