#include<stdio.h>
#include<stdlib.h>
#define SIZE 5
#define PRIME 2
int arr[SIZE];
void insertion();
void deletion();
void traverse();
void search();
void main(){   
    for(int i=0;i<SIZE;i++){
        arr[i]=-1;
    }
     while(1){
        int op;
        scanf("%d",&op);
        switch(op){
            case 1:
            insertion();
            break;
            case 2:
            deletion();
            break;
            case 3:
            traverse();
            break;
            case 4:
            search();
            break;
            default:
            exit(0);
            break;
        }
     }
}
void insertion(){
        int op,i;
        printf("Enter the value");
        scanf("%d",&op);
        int h1=op%SIZE;
        int h2=PRIME-op%PRIME;
        for(i=0;i<SIZE;i++){
            if(arr[(h1+h2*i+1)%SIZE]==-1){
                arr[(h1+h2*i+1)%SIZE]=op;
                break;
            }
        }
        if(i==SIZE){
            printf("no slot is there");
        }
}
void deletion(){
       int op,i;
        printf("Enter the value");
        scanf("%d",&op);
        int h1=op%SIZE;
        int h2=PRIME-op%PRIME;
        for(i=0;i<SIZE;i++){
            if(arr[(h1+h2*i+1)%SIZE]==op){
                arr[(h1+h2*i+1)%SIZE]=-1;
                break;
            }
        }
        if(i==SIZE){
            printf("Element is not found");
        }
}
void traverse(){
    int i;
    for(i=0;i<SIZE;i++){
        if(arr[i]==-1){
            printf("element is not found at%d\n",(i));
        }
        else{
            printf("elemet is found %d at %d\n",arr[i],(i));
        }
    }
}
void search(){
     int op,i,found=0;
        printf("Enter the value");
        scanf("%d",&op);
        int h1=op%SIZE;
        int h2=PRIME-op%PRIME;
        for(i=0;i<SIZE;i++){
            if(arr[(h1+h2*i+1)%SIZE]==op){
                found=1;
                break;
            }
        }
        if(found==0){
            printf("Element is not found");
        }else{
            printf("Element is found");
        }
}