//Linear probing
#include<stdio.h>
#include<stdlib.h>
#define SIZE 5
int arr[SIZE];
void insertion();
void deletion();
void traverse();
void search();
void main(){   
    for(int i=0;i<SIZE;i++){
        arr[i]=-1;
    }
    printf("\nchoose an operation to perform:\n");
    printf("1.Insertion\n");
    printf("2.Deletion\n");
    printf("3.Traverse\n");
    printf("4.search\n");
    int m;
    do{
         printf("\nEnter the choice:");
         scanf("%d",&m);
      switch(m){
        case 1:insertion();
               break;
        case 2:deletion();
               break;
        case 3:traverse();
               break;
        case 4:search();
               break;
        case 5:exit(0);
      }
    }while(m!=5);
}
void insertion(){
    int i,hkey,value;
    printf("Enter a value to insert:");
    scanf("%d",&value);
    hkey=value%SIZE;
    for(i=0;i<SIZE;i++){
        if(arr[(hkey+i)%SIZE]==-1){
            arr[(hkey+i)%SIZE]=value;
            break;
        }
    }
    if(i==SIZE){
        printf("There is no free slot\n");
    }
}
void deletion(){
     int i,hkey,value;
     printf("Enter the value to delete:");
     scanf("%d",&value);
     hkey=value%SIZE;
     for(i=0;i<SIZE;i++){
         if(arr[(hkey+i)%SIZE]==value){
            arr[(hkey+i)%SIZE]=-1;
            break;
         }
     }
     if(i==SIZE){
        printf("No record found\n");
     }
}
void traverse(){
    for(int i=0;i<SIZE;i++){
        if(arr[i]==-1){
            printf("Bucket-%d is empty\n",i);
        }
        else{
        printf("Bucket-%d contains-%d\n",i,arr[i]);
        }
    }
}
void search(){
    int i,hkey,value,found=0;
    hkey=value%SIZE;
    printf("Enter the value to search:");
    scanf("%d",&value);
    for(i=0;i<SIZE;i++){
        if(arr[(hkey+i)%SIZE]==value){
            found=1;
            break;
        }

    }
    if(found==1){
        printf("element is found\n");
    }
    else{
        printf("search is unsuccessful\n");
    }
}