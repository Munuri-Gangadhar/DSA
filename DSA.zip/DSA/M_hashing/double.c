//double hashing
#include<stdio.h>
#include<stdlib.h>
#define SIZE 13
#define PRIME 7
int arr[SIZE];
void insertion();
void deletion();
void traverse();
void search();
void main(){
    int m;
    for(int i=0;i<SIZE;i++){
        arr[i]=-1;
    }
    printf("\nChoose an operation from below\n");
    printf("1.Insertion\n");
    printf("2.Deletion\n");
    printf("3.Traverse\n");
    printf("4.search\n");
    do{
      printf("\nEnter the choice:");
      scanf("%d",&m);
      switch(m){
        case 1:insertion();
               break;   
        case 2:deletion();
              break;
        case 3:traverse();
               break;
        case 4:search();
               break;
        case 5:exit(0);
      }
    }while(m!=5);
}
void insertion(){
    int value,h1key,h2key,i;
    printf("Enter the value to insert:");
    scanf("%d",&value);
    h1key=value%SIZE;
    h2key=PRIME-value%PRIME;
    for(i=0;i<SIZE;i++){
        if(arr[(h1key+i*h2key+1)%SIZE]==-1){
           arr[(h1key+i*h2key+1)%SIZE]=value;
           break;
        }
    }
    if(i==SIZE){
        printf("There is no free slot\n");
    }
}
void deletion(){
    int value,h1key,h2key,i;
    printf("Enter the value to delete:");
    scanf("%d",&value);
    h1key=value%SIZE;
    h2key=PRIME-value%PRIME;
    for(i=0;i<SIZE;i++){
        if(arr[(h1key+i*h2key+1)%SIZE]==value){
           arr[(h1key+i*h2key+1)%SIZE]=-1;
           break;
        }
    }
    if(i==SIZE){
        printf("No record found\n");
    }
}
void traverse(){
    for(int i=0;i<SIZE;i++){
      if(arr[i]==-1){
        printf("Bucket-%d is empty\n",i);
      }
      else{
        printf("Bucket-%d contains-%d\n",i,arr[i]);
      }
    }
}
void search(){
    int value,h1key,h2key,found=0;
    printf("Enter the value to search:");
    scanf("%d",&value);
    h1key=value%SIZE;
    h2key=PRIME-value%PRIME;
    for(int i=0;i<SIZE;i++){
          if(arr[(h1key+i*h2key+1)%SIZE]==value){
           found=1;
           break;
        }
    }
    if(found==1){
        printf("Search is successful\n");
    }
    else{
        printf("search is unsuccessful\n");
    }
}