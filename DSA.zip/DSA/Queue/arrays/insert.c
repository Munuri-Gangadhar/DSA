#include<stdio.h>
#include<stdlib.h>
#define max 5
int Q[max],rear=-1,front=-1;
void Enqueue();
void Dequeue();
void traverse();
int main(){
    int op;
    while(1){
        printf("Enter your option:");
        scanf("%d",&op);
        switch(op){
            case 1:
            Enqueue();
            break;
            case 2:
            Dequeue();
            break;
            case 3:
            traverse();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void Enqueue(){
    int ele;
    if(rear==max-1){
        printf("Queue is full\n");
    }
    else{
        rear=rear+1;
        printf("enter the element:");
        scanf("%d",&ele);
        Q[rear]=ele;
    }
    if(rear==0){
       front=0;
    }
    
}
void Dequeue(){
    if(rear==-1){
        printf("\nQueue is empty");
    }
    else{
        printf("Deleted element:");
        printf("%d\n",Q[front]);
        front=front+1;
        if(front==rear)
         front=rear=-1;
    }
    // if(front>rear){
    //     front=rear=-1;
    // }
}
void traverse(){
    int i;
    if(front==-1){
        printf("Queue is empty\n");
    }
    else{
       for(i=front;i<=rear;i++){
        printf("%d\n",Q[i]);
       }
    }
}

