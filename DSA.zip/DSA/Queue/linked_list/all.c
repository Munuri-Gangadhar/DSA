#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*front=NULL,*p,*temp,*rear=NULL;
void enqueue();
void dequeue();
void traverse();
int main(){
    int op;
    while(1){
        printf("enter the operation");
        scanf("%d",&op);
        switch(op){
            case 1:
            enqueue();
            break;
            case 2:
            dequeue();
            break;
            case 3:
            traverse();
            break;
            default:
            exit(0);
            break;
        }
    }
}
void enqueue(){
      int data;
      temp=(struct node*)malloc(sizeof(struct node));
      printf("enter the data:");
      scanf("%d",&data);
      temp->data=data,temp->next=NULL;
      if(front==NULL){
        front=temp;
        rear=temp;
      }
      else{
        rear->next=temp;
        rear=temp;
      }
}
void dequeue(){
   if(front==NULL){
     printf("queue is empty");
   }
   else{
     temp=front;
     front=front->next;
     temp->next=NULL;
     free(temp);
   }
}
void traverse(){
   if(front==NULL){
    printf("queue is empty");
   }
   else{
     p=front;
     while(p!=NULL){
       printf("%d\n",p->data);
       p=p->next;
     }
   }
}