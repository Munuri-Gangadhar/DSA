#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *left,*right;
}*temp;
struct node*create(struct node *root){
    int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&data);
    temp->data=data;
    if(data==-1){
        return 0;
    }
    if(root==NULL || root->data==data)
        return create(root);
    if(root->data<data){
         printf("Entered is inserted right side of %d",root->data);
         return create(root->right);
    }
    if(root->data>data){
          printf("Entered is inserted left side of %d",root->data);
          return create(root->left);
    }
    return root;
}
int main(){
    struct node *root;
    root=NULL;
    root=create(root);
    
}