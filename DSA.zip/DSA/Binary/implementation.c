#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *left,*right;
};
struct node *create();
void preorder(struct node *root);
void Inorder(struct node *root);
void postorder(struct node *root);
// void traverse(struct node *root);
int main(){
   struct node *RT;
   RT=NULL;
   int op;
   printf("1.Creation of Binary tree \n2.Inorder Traverse \n3.Postorder Traverse \n4.Preorder Traverse");
   while(1){
    printf("\nEnter the operation:");
    scanf("%d",&op);
    switch(op){
        case 1:
        RT=create(); 
        break;
        case 2:
        printf("Inorder is:");
        Inorder(RT);
        break;
        case 3:
        printf("postorder is:");
        postorder(RT);
        break;
        case 4:
        printf("Preorder is:");
        preorder(RT);
        break;
        default:
        exit(0);
        break;

    }
   }
}

//This traverse operation is wrong  
//This is only for testing

// void traverse(struct node *root){
//     if(root==NULL){
//         printf("There is no leaf for the root node");
//     }
//     else{
//         printf("%d\n",root->data);
//         if(root->left->data==-1){
//             return 0;
//         }
//         printf("%d\n",root->left->data);
//         traverse(root->left);
//         printf("%d\n",root->right->data);
//         traverse(root->right);

//          return root;

//     }
    
// }
void preorder(struct node *root){
    if(root==NULL){
        return ;
    }
    else{
    printf("%d\t",root->data);
    preorder(root->left);
    preorder(root->right);
    } 
}
void Inorder(struct node *root){
    if(root==0){
        return ;
    }
    else{
        Inorder(root->left);
        printf("%d\t",root->data);
        Inorder(root->right);
    }
}
void postorder(struct node *root){
    if(root==NULL){
        return ;
    }
    else{
    postorder(root->left);
    postorder(root->right);
    printf("%d\t",root->data);
    } 
}
struct node *create(){
    int x;
    struct node *newnode;
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("enter the data");
    scanf("%d",&x);
    newnode->data=x;
    if(x==-1){
        return 0;
    }
    printf("enter the left leaf%d\n",x);
    newnode->left=create();
    printf("enter the right leaf %d\n",x);
    newnode->right=create();
    return newnode;
}