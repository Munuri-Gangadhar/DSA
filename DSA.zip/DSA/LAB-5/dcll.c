#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*prev;
    struct node*next;
}*start=NULL,*temp,*p,*ptr,*end;
void create();
void traverse();
void insert_start();
void insert_end();
void insert_pos();
void delete_start();
void delete_end();
void delete_pos();
int main(){
    printf("--------Select your option-------\n");
    int op;
    while(1){
    printf("\nEnter your option");
    scanf("%d",&op);
      switch(op){
        case 1:
        create();
        break;
        case 2:
        traverse();
        break;
        case 3:
        insert_start();
        break;
        case 4:
        insert_end();
        break;
        case 5:
        insert_pos();
        break;
        case 6:
        delete_start();
        break;
        case 7:
        delete_end();
        break;
        case 8:
        delete_pos();
        break;
        default:
        exit(0);
        break;
      }
   
    }

    return 0;
}
void create(){
    int i,ele,x;
    printf("Enter the no.of nodes:");
    scanf("%d",&ele);
    for(i=0;i<ele;i++){
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter the data:");
    scanf("%d",&x);
    temp->next=NULL;
    temp->prev=NULL;
    temp->data=x;
    if(start==NULL){
      start=temp;
      start->next=start;
      start->prev=start;
      end=temp;
    }
    else{
         end->next=temp;
         temp->prev=end;
         temp->next=start;
         start->prev=temp;
         end=temp;
    }
}
      traverse();
}
void traverse(){
     if(start==NULL){
        printf("list is empty");
     }
     else{
         ptr=start;
         while(ptr->next!=start){
             printf("%d\n",ptr->data);
             ptr=ptr->next;
         }
         printf("%d",ptr->data);
     }
}
void insert_start(){
    int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter the data");
    scanf("%d",&data);
    temp->data=data;
    temp->next=NULL;
    temp->prev=NULL;
    if(start==NULL){
       start=temp;
      start->next=start;
      start->prev=start;
      end=temp;
    }
    else{
        temp->next=start;
        start->prev=temp;
        temp->prev=end;
        end->next=temp;
        start=temp;       
    }
}
void insert_end(){
    int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter the data");
    scanf("%d",&data);
    temp->data=data;
    temp->next=NULL;
    temp->prev=NULL;
   if(start==NULL){
      start=temp;
      start->next=start;
      end=temp;
   }
   else{
      end->next=temp;
      temp->prev=end;
      temp->next=start;
      start->prev=temp;
      end=temp;
   }
   traverse();
}
void insert_pos(){
    int c=1,pos,i,data;
    p=start;
    while(p->next!=start){
        c=c+1;
        p=p->next; 
    }
    printf("No.of nodes in the list is:%d\n",c);
    printf("Enter the position:");
    scanf("%d",&pos);
    if(pos==1){
        insert_start();
    }
    else if(pos==c){
        insert_end();
    }
    else if(pos>1 && pos<c){
    p=start;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter the data");
    scanf("%d",&data);
    temp->data=data;
    temp->next=NULL;
    temp->prev=NULL;
    for(i=1;i<pos-1;i++){
           p=p->next;
      }
      temp->next=p->next;
      p->next->prev=temp;
      p->next=temp;
      temp->prev=p; 
    }
    else{
        printf("invalid position entered");
    }
}
void delete_start(){
    if(start==NULL){
        printf("list is empty");
    }
    else if(start->next==start){
          start=NULL;
          free(start);
    }
    else{
        p=start;   
        while(p->next!=start)  
        {  
            p=p->next;  
        }  
        p->next=start-> next;  
        start->next->prev=p;
        free(start);  
        start=p->next;
          
    }
      traverse();
}
void delete_end(){
     if(start==NULL){
        printf("list is empty");
    }
    else if(start->next==start){
         temp=start;
         temp=NULL;
         free(temp);
    }
    else{
       struct node*k;
       p=start;   
        while(p->next!=start)  
        {  
            k=p;
            p=p->next;  
        }
        temp=p;
        k->next=start;
        start->prev=k;
        temp->next=NULL;
        temp->prev=NULL;
        free(temp);
    }
}
void delete_pos(){
     int c=1,pos,i;
     p=start;
     while(p->next!=start){
        c=c+1;
        p=p->next;
     }
    printf("No.of nodes in the list%d\n",c);
    printf("Enter the position:");
    scanf("%d",&pos);
    if(pos==1){
        delete_start();
    }
    else if(pos==c){
        delete_end();
    }
    else if(pos>1 && pos<c){
        p=start;
         for(i=1;i<pos-1;i++){
             p=p->next;
         }
         temp=p->next;
         p->next=p->next->next;
         temp->next->prev=p;
         free(temp);
    }
    else{
        printf("invalid postion");
    }
}