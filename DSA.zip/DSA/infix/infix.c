 /*#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 100

char stack[MAX];

char infix[MAX],postfix[MAX];

int top=-1;


int precedence(char sym){
	switch(sym){
		case '^':
			return 3;
		case '*':
		case '/':
			return 2;
		case '+':
		case '-':
			return 1;
		default:
			return 0;
	}	
}


 
int space(char c){
	if(c==' ' || c=='\t')
		return 1;
	else
		return 0;
}


void print(){
	int i=0;
	printf("the equivalent postfix expression is: ");
	while(postfix[i]){
		printf("%c ",postfix[i++]);
	}
	printf("\n");
}


void push(char c){
	if(top==MAX-1){
		printf("stack overflow");
		return;
	}
	top++;
	stack[top]=c;
}

char pop(){
	char c;
	if(top==-1){
		printf("stack underflow \n");
		exit(1);
	}
	c=stack[top];
	top=top-1;
	return c;
}

int isEmpty(){
	if(top==-1)
		return 1;
	else
		return 0;
}

 


void inToPost(){
	int j=0;
	char sym,next;
	for(int i=0;i<strlen(infix);i++){
		sym=infix[i];
	if(!space(sym)){
	switch(sym){
		case '(':{
			push(sym);
			break;
			}
		case ')':
			while((next=pop())!='(')
				postfix[j++]=next;
			break;
		case '+':
		case '-':
		case '*':
		case '/':
		case '^':
			while(!isEmpty() && precedence(stack[top])>=precedence(sym))
				postfix[j++]=pop();
			push(sym);
			break;	
		default:
			postfix[j++]=sym;
	}

	}
	}
	
	while(!isEmpty()){
		postfix[j++]=pop();
	}
	postfix[j]='\0';
}



int main(){

	printf("enter the infix expression: ");
	gets(infix);

	inToPost();
	print(); 
}

*/
 #include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

#define MAX 100

int stack[MAX];

char infix[MAX],postfix[MAX];

int top=-1;


int precedence(char sym){
	switch(sym){
		case '^':
			return 3;
		case '*':
		case '/':
			return 2;
		case '+':
		case '-':
			return 1;
		default:
			return 0;
	}	
}
int powe(int a,int b){
	int i,mul=1;
	for(i=0;i<b;i++){
		mul=mul*a;
	}
	return mul;
}

 
int space(char c){
	if(c==' ' || c=='\t')
		return 1;
	else
		return 0;
}


void print(){
	int i=0;
	printf("the equivalent postfix expression is: ");
	while(postfix[i]){
		printf("%c ",postfix[i++]);
	}
	printf("\n");
}


void push(char c){
	if(top==MAX-1){
		printf("stack overflow");
		return;
	}
	top++;
	stack[top]=c;
}

char pop(){
	char c;
	if(top==-1){
		printf("stack underflow \n");
		exit(1);
	}
	c=stack[top];
	top=top-1;
	return c;
}
int isEmpty(){
	if(top==-1)
		return 1;
	else
		return 0;
}
void inToPost(){
	int j=0;
	char sym,next;
	for(int i=0;i<strlen(infix);i++){
		sym=infix[i];
	if(!space(sym)){
	switch(sym){
		case '(':{
			push(sym);
			break;
			}
		case ')':
			while((next=pop())!='(')
				postfix[j++]=next;
			break;
		case '+':
		case '-':
		case '*':
		case '/':
		case '^':
			while(!isEmpty() && precedence(stack[top])>=precedence(sym))
				postfix[j++]=pop();
			push(sym);
			break;	
		default:
			postfix[j++]=sym;
	}

	}
	}
	
	while(!isEmpty()){
		postfix[j++]=pop();
	}
	postfix[j]='\0';
}





int post_eval(){
	int a,b;
	for(int i=0;i<strlen(postfix);i++){
		if(postfix[i]>='0' && postfix[i]<='9')
			push(postfix[i]-'0');
		else{
			a=pop();
			b=pop();
			int c;
			switch(postfix[i]){
				case '+':
					push(b+a);
					break;
				case '-':
					push(b-a);
					break;
				case '*':
					push(b*a);
					break;
				case '/':
					push(b/a);
					break;
				case '^':
					c=powe(b,a);
					push(c);
					break;
			}
		}
	}
	return pop();


}






int main(){
	int result;

	printf("enter the infix expression: ");
	gets(infix);

	inToPost();
	result=post_eval();
	print();

	printf("the result obtained after postfix evalution is: ");
	printf("%d \n",result);
}

// */