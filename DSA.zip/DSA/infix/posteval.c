#include<stdio.h>
#include<string.h>
void push(char);
char pop();
void display();
int isoperand(char);
char st[100]={'\0'};
int top=-1;
char ch;
void main()

{
	char postfix[100]={'\0'};
	char x;
	int i, j;
	printf("enter a postfix expression");
	scanf("%s",&postfix);
	printf("\n postfix expression=%s",postfix);
	i=0;
	while(i<strlen(postfix))
	{
		x=postfix[i];
		if(isoperand(x))
		{
			push(x);
			push(' ');
			printf("\n element=%c push to stack",x);
		}
		else
		{
			printf("\n operator = %c ",x);
			for(j=top-1; j>=0; j--)
			{
				if(st[j]==' ')
				{
					st[j]=x;
					break;
				}
			}
		}
		i++;
		display();
		printf("\n----------");
	}
	printf("\n infix expression= %s",st);
}
void push(char x)
{
	if(top==99)
	{
		printf("\n stack is full:");
	}
	else
	{
		top++;
		st[top]=x;
	}
}
int isoperand(char x)
{
	if((x>='A'&&x<='Z')||(x>='a'&&x<='z'))
	return 1;
	else
	return 0;
}
char pop()
{
	if(top==-1)
	{
		printf("stack is empty:");}
		else
		{
			ch=st[top];
			top--;
		}
		return ch;
}
void display()
{
	int i;
	for(i=0; i<=top; i++)
	{
		printf("\n s[%d]=%c",i,st[i]);
	}
}
