#include<stdio.h>
#include<string.h>
void push(char);
char pop();
void display();
int isoperand(char);
char st[100]={'\0'};
int top=-1;
char ch;
void main()
{
	char prefix[100]={'\0'};
	char x;
	int i, j;
	printf("Enter a prefix expression");
	scanf("%s",&prefix);
	i=strlen(prefix)-1;
	while(i>=0)
	{
		x=prefix[i];
		if(isoperand(x))
		{
			push(x);
			push(' ');
			printf("\n element=%c",x);
		}
		else
		{
			printf("\n operator = %c ",x);
			for(j=top-1; j>=0; j--)
			{
				if(st[j]==' ')
				{
					st[j]=x;
					break;
				}
			}
		}
		i--;
		printf("\n----------");
	}
	printf("\n infix expression= %s",strrev(st));
}
void push(char x)
{
	if(top==99)
	{
		printf("\n stack is full:");
	}
	else
	{
		top++;
		st[top]=x;
	}
}
int isoperand(char x)
{
	if((x>='A'&&x<='Z')||(x>='a'&&x<='z'))
	return 1;
	else
	return 0;
	
}
char pop()
{
	if(top==-1)
	{
		printf("stack is empty:");}
		else
		{
			ch=st[top];
			top--;
		}
		return ch;
}
void display()
{
	int i;
	for(i=0; i<=top; i++)
	{
		printf("\n s[%d]=%c",i,st[i]);
	}
}
