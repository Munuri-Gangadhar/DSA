#include<string.h>
#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<math.h> 
int stack[50],top=-1;
int peroperation(int,int,char);
int main()
{
	printf("enter the pre fix expression:");
	char expression[50];
	gets(expression);
	strrev(expression);
	int i,j;
	for(i=0;expression[i]!='\0';i++)
	{
		char ch=expression[i];
		if(isdigit(ch))
		{
			top++;
	    	stack[top]=(int)expression[i]-48;
		}
		else
		{
			int b=stack[top--];
			int a=stack[top];
			int c=peroperation(a,b,ch);
			stack[top]=c;
		}
	}
	printf("evelutaded answer is :%d",stack[top]);
}
int peroperation(int a,int b,char symb)
{
	switch(symb)
	{
		case '+':return (b+a);break;
		case '-':return (b-a);break;
		case '*':return (b*a);break;
		case '/':return (b/a);break;
		case '%':return (b%a);break;
		case '^':return pow(b,a);break;	
	}
}