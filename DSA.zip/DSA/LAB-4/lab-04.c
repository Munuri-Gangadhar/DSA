//circular linked list
#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*start=NULL,*temp,*p,*end;
void create();
void traverse();
void insert_start();
void insert_end();
void insert_pos();
void delete_start();
void delete_end();
void delete_pos();
int main(){
    printf("======Select any option======   \n1.Creation \n2.Traverse \n3.Insert at start position \n4.Insert at end position \n5.Insert at the specified position \n6.Delete at start \n7.Delete at end \n8.Delete at specified postion");
    int op;
    while(op!=-1){
        printf("\nEnter the your operation:");
        scanf("%d",&op);
        switch(op){
            case 1:
            create();
            printf("\nEnter  -1 to exit");
            break;
            case 2:
            traverse();
            printf("\nEnter -1 to exit");
            break;
            case 3:
            insert_start();
            printf("\nEnter -1 to exit");
            break;
            case 4:
            insert_end();
            printf("\nEnter -1 to exit");
            break;
            case 5:
            insert_pos();
            printf("\nEnter -1 to exit");   
            break;
            case 6:
            delete_start();
            printf("\nEnter -1 to exit");
            break;
            case 7:
            delete_end();
            printf("\nEnter -1 to exit");
            break;
            case 8:
            delete_pos();
            printf("\nEnter -1 to exit");
            break;
            default:
            printf("Thank you!!");
            break;
        }
    }
}
void create(){
    int data,i,ele;
    printf("Enter No.of nodes");
    scanf("%d",&ele);
    for(i=0;i<ele;i++){
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&data);
    temp->data=data;
    temp->next=NULL;
    if(start==NULL){
        start=temp;
        start->next=start;
        end=temp;
    }
    else{
        end->next=temp;
        temp->next=start;
        end=temp;
    }
}
   traverse();
}
void traverse(){
    p=start;
    if(p==NULL){
        printf("list is empty");
    }
    else{
        while(p->next!=start){
            printf("%d\n",p->data);
            p=p->next;
        }
        printf("%d",p->data);
    }
}
void insert_start(){
    int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&data);
    temp->next=NULL;
    temp->data=data;
    if(start==NULL){
        start=temp;
        start->next=start;
    }
    else{
        end->next=temp;
        temp->next=start;
        start=temp; 
    }
    traverse();
}
void insert_end(){
     int data;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&data);
    temp->next=NULL;
    temp->data=data;
    if(start==NULL){
        start=temp;
        start->next=start;
    } 
    else{
        end->next=temp;
        temp->next=start;
        end=temp;
    }
    traverse();
}
void insert_pos(){
    int count=1;
    p=start;
    while(p->next!=start){
        count=count+1;
        p=p->next;
    }
    printf("NO.OF NODES:%d:\n",count);
    count=count+1;
    int pos,k;
    printf("Enter the position:");
    scanf("%d",&pos);
    if(pos==1)
    insert_start();
    else if(pos==count)
    insert_end();
    else if(pos>1 && pos<count){
        int data;
        temp=(struct node*)malloc(sizeof(struct node));
        printf("enter the data:");
        scanf("%d",&data);
        temp->next=NULL;
        temp->data=data;
        p=start;
        for(k=1;k<pos-1;k++){
            p=p->next;
        }
        temp->next=p->next;
        p->next=temp;
    }
    else{
        printf("Invalid position");
    }
    traverse();   
}
void delete_start(){
  if(start==NULL){
    printf("list is empty");
  }
  else{
    temp=start;
    end->next=temp->next;
    start=start->next;
    free(temp);
  }
   traverse();
}
void delete_end(){
   if(start==NULL){
    printf("list is empty");
   }
   else if(start->next==start){
    start=NULL;
    free(start);
   }
   else{
      temp=start;
      while(temp->next!=start){
        p=temp;
        temp=temp->next;
      }
      p->next=start;
      temp->next=NULL;
      free(temp);
   }
   traverse();
}
void delete_pos(){
    int count=1,pos,k;
    p=start;
    while(p->next!=start){
       p=p->next;
       count=count+1;
    } 
    printf("enter the position:");
    scanf("%d",&pos);
    if(pos==1){
        delete_start();
    }
    else if(pos==count){
        delete_end();
    }
    else if(pos>1 && pos<count){
        p=start;
        for(k=1;k<pos-1;k++){
            p=p->next;
        }
        temp=p->next;
        p->next=temp->next;
        temp->next=NULL;
        free(temp);
    }
    else{
        printf("Invalid position\n");
    }
   traverse();
}