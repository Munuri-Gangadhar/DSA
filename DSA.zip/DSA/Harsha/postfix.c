#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 20
void intopost();
int precedence(char);
char pop();
void print();
int isEmpty();
void push(char);
int top=-1;
char infix[MAX];
char postfix[MAX];
char stack[MAX];
int main()
{
    printf("Enter the infix expression ");
    gets(infix);
    intopost();
    print();
}
void intopost()
{
    int i,j=0;
    char symbol,next;
    for(i=0;i<strlen(infix);i++)
    {
        symbol=infix[i];
        switch (symbol)
        {
        case '(':
            push(symbol);
            break;
        case ')':
            while((next=pop())!='(')
            {
                postfix[j++]=next;
            }
            break;
        case '+':
        case '-':
        case '/':
        case '*':
        case '^':
            while(!isEmpty()&&precedence(stack[top])>=precedence(symbol))
            {
                postfix[j++]=pop();
            }
            push(symbol);
            break;
        default:
            postfix[j++]=symbol;
        }
    }
    while(!isEmpty())
    {
        postfix[j++]=pop();
    }
    postfix[j]='\0';
}
int precedence(char symbol)
{
    switch (symbol)
    {
    case '^':
        return 3;
    case '/':
    case '*':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}
void print()
{
    int i=0;
    printf("The equivalent postfix expression is\t");
    while(postfix[i])
    {
        printf("%c",postfix[i++]);
    }
    printf("\n");
}
int isEmpty()
{
    if(top==-1)
        return 1;
    else
        return 0;
}
char pop()
{
    char c;
    if(top==-1)
    {
        printf("Stack Underflow");
        exit(1);
    }
    c=stack[top];
    top=top-1;
    return c;
}
void push(char c)
{
    if(top==MAX-1)
    {
        printf("Stack Overflow\n");
        return;
    }
    top++;
    stack[top]=c;
}
