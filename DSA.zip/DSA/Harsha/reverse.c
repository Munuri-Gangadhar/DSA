#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define MAX 100
char stack[100];
int top=-1;
void pop();
void push(char s);
int main(){
    char s[10];
    printf("Enter the String:");
    gets(s);   
    for(int i=0;i<strlen(s);i++){
        push(s[i]);
    } 
    for(int i=0;i<strlen(s);i++){
        pop();
    }
    
}
void push(char c){
    if(top==MAX-1){
        printf("statck is overflow");
    }
    else{
    top=top+1;
    stack[top]=c;
    }
   
}
void pop(){
    printf("%c",stack[top--]);
}