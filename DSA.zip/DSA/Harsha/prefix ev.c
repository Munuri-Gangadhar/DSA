#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#define MAX 25
int top=-1;
float s[MAX],o,val;
float eval_prefix(char p[]);
void push_stack(float k);
float pop(float s[]);
int main()
{
    char p[MAX];  
    printf("Enter the prefix expression :");
    gets(p);
    strrev(p);
    o=eval_prefix(p);
    printf("The value of the prefix expression is:%f\n",o);
}
void push_stack(float k)
{
    if(top==MAX-1)   
    {
        printf("Stack is overflown\n");
    } 
    else
    {
        top=top+1;
        s[top]=k;
    }
}
float pop(float s[])
{
    float val=-1;    
    if(top==-1) 
    {
        printf("Stack is empty.\n");
    }   
    else
    {
        val=s[top];
        top--;
    }    
    return val;
}
float eval_prefix(char p[])
{
    int i=0;
    float value,op1,op2;
    while(p[i]!='\0')
    {
        if(isdigit(p[i]))
        {
            push_stack((float)(p[i]-'0'));
        }
        else
        {   
            op1=pop(s);
            op2=pop(s);
            switch(p[i])
            {
                case '+':value=op1+op2;
                        break;
                case '-':value=op1-op2;
                        break;
                case '*':value=op1*op2;
                        break;
                case '/':value=op1/op2;
                        break;
                case '%':value=(int)op1%(int)op2;
                        break;
                case '^':value=pow(op1,op2);
                        break;                                       
            }
            push_stack(value);
        }
        i++;
    }
     return pop(s);
}
