#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 20
void intopre();
int precedence(char);
char pop();
void print();
int isEmpty();
void push(char);
int top=-1;
char infix[MAX];
char reverse[MAX];
char prefix[MAX];
char stack[MAX];
int main()
{
    printf("Enter the infix expression\n");
    gets(infix);
    int i=0;
    int l=strlen(infix);
    while(infix[i]!='\0')
    {
        reverse[i]=infix[l-i-1];
        i++;
    }
    intopre();
    print();
}
void intopre()
{
    int i,j=0;
    char symbol,next;
    for(i=0;i<strlen(reverse);i++)
    {
        symbol=reverse[i];
        switch (symbol)
        {
            case ')':
                push(symbol);
                break;
            case '(':
                while((next=pop())!=')')
                {
                    prefix[j++]=next;
                }
                break;
            case '+':
            case '-':
            case '/':
            case '*':
            case '^':
                while(!isEmpty()&&precedence(stack[top])>precedence(symbol))
                {
                    prefix[j++]=pop();
                }
                push(symbol);
                break;
            default:
                prefix[j++]=symbol;
        }
    }
    while(!isEmpty())
    {
        prefix[j++]=pop();
    }
    prefix[j]='\0';
}
int precedence(char symbol)
{
    switch (symbol)
    {
    case '^':
        return 3;
    case '/':
    case '*':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}
void print()
{
    int i=0;
    printf("The equivalent prefix expression is\t");
    int l=strlen(prefix);
    while(prefix[i]!='\0')
    {
        printf("%c",prefix[l-i-1]);
        i++;
    }
    printf("\n");
}
void push(char c)
{
    if(top==MAX-1)
    {
        printf("Stack Overflow\n");
        return;
    }
    top++;
    stack[top]=c;
}
char pop()
{
    char c;
    if(top==-1)
    {
        printf("Stack Underflow");
        exit(1);
    }
    c=stack[top];
    top=top-1;
    return c;
}
int isEmpty()
{
    if(top==-1)
        return 1;
    else
        return 0;
}
