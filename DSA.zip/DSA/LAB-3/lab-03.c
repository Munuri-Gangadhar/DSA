#include<stdio.h>
#include<stdlib.h>
struct node{
   struct node *prev;
   int data; 
   struct node *next;
}*start=NULL,*temp,*p,*end,*ptr;
void create();
void traverse();
void display_reverse();
void insert_beg();
void insert_end();
void insert_pos();
void del_start();
void del_end();
void del_pos();
int main(){
    printf("======Select any option======  \n1.Creation \n2.Traverse \n3.Display Reverse \n4.Insert at start position \n5.Insert at end position \n6.Insert at the specified position \n7.Delete at start \n8.Delete at end \n.9.Delete at specified position");
    int op;
    while(1){
        printf("\nEnter the option");
        scanf("%d",&op);
        switch(op){
            case 1:
            create();
            break;
            case 2:
            traverse();
            break;
            case 3:
            display_reverse();
            break;
            case 4:
            insert_beg();
            break;
            case 5:
            insert_end();
            break;
            case 6:
            insert_pos();
            break;
            case 7:
            del_start();
            break;
            case 8:
            del_end();
            break;
            case 9:
            del_pos();
            break;
            default:
            exit(0);
            break;
        }
    }
    
}
void create(){
   int i,n;
   printf("enter the no.of nodes");
   scanf("%d",&n);
   for(i=0;i<n;i++){
    int m;
    temp=(struct node*)malloc(sizeof(struct node*));
    temp->prev=NULL;
    temp->next=NULL;
      printf("Enter the data");
      scanf("%d",&m);
      temp->data=m;
      if(start==NULL){
        start=temp;
        p=temp;
      }
      else{
        p->next=temp;
        temp->prev=p;
        p=temp;
      }  
   }  
   traverse();  
}
void traverse(){
//    struct node *ptr;
   if(start==NULL){
    printf("The D.L.L is empty");
   }    
   else{
    ptr=start;
    while(ptr!=NULL){
        printf("%d\n",ptr->data);
        ptr=ptr->next;
    }
   }
}
void display_reverse(){
if(start==NULL){
      printf("no data is present");
}
else{
    end=p;
    while(end!=NULL){
        printf("%d\n",end->data);
        end=end->prev;
    }
   }
}
void insert_beg(){
    int x;
    printf("enter the element");
    scanf("%d",&x);
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->prev=NULL;
    temp->next=NULL;
    if(start==NULL){
        start=temp;
        p=temp;
    }
    else{
        temp->next=start;
        start->prev=temp;
        start=temp;
    }  
    traverse();
}
void insert_end(){
    int x;
    printf("enter the element");
    scanf("%d",&x);
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->prev=NULL;
    temp->next=NULL;
    if(start==NULL){
        start=temp;
        p=temp;
    }
    else{
        p->next=temp;
        temp->prev=p;
        p=temp;
    }
    traverse();
}
void insert_pos(){
    // struct node *ptr;
    ptr=start;
    int c=0,pos,m;
    while(ptr!=NULL){
         ptr=ptr->next;
         c=c+1;
    } 
    printf("No.of node  is:%d\n",c);
    ptr=start;
    printf("enter the position");
    scanf("%d",&pos);
    if(pos==1){
        insert_beg();
    }
    else if(pos==c+1){
        insert_end();
    }
    else if(pos>1 && pos<c+1){
        printf("enter the element");
        scanf("%d",&m);
        temp=(struct node*)malloc(sizeof(struct node));
        temp->prev=NULL;
        temp->next=NULL;
        temp->data=m;
        for(int i=1;i<pos-1;i++){
               ptr=ptr->next;
        }
        temp->next=ptr->next;
        ptr->next->prev=temp;
        ptr->next=temp;
        temp->prev=ptr->next;
    }
    else{
        printf("invalid position");
    }
    traverse();
}
void del_start(){
    
     if(start==NULL){
        printf("dll is empty");
     }
     else if(start->next==NULL){
           temp=start;
           start->next=NULL;
           free(temp);
     }
     else{
        ptr=start;
        start=start->next;
        start->prev=NULL;
        ptr->next=NULL;
        free(ptr);
     }
     traverse();
}
void del_end(){
    if(start==NULL)
    printf("list is empty");
    else{
       ptr=start;
       while(ptr->next->next!=NULL){
           ptr=ptr->next;
       }
       temp=ptr->next;
       ptr->next=NULL;
       temp->prev=NULL;
       free(temp);
    }
    traverse();
}
void del_pos(){
    ptr=start;
    int count=0,pos,i;
    while(ptr!=NULL){
        count++;
        ptr=ptr->next;
         
    }
    printf("Enter position to delete:");
    scanf("%d",&pos);
    if(pos==1){
       del_start();
  }
   else if(pos==count){
      del_end();
}
   else if(pos>1 && pos<count){
     ptr=start;
    for(i=1;i<pos-1;i++){
       ptr=ptr->next;
    }
    // p->next=p->next->next;
    // temp=p->next;
    // temp->next=NULL;
    temp=ptr->next;
    ptr->next=temp->next;
    temp->next->prev=ptr;
    temp->next=NULL;
    temp->prev=NULL;
    free(temp);
   }
   traverse();
}


