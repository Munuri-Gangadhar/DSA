#include<stdio.h>
#include<stdlib.h>
int a[100];
void countSort(int arr[], int n, int exp)
{
	int output[n]; // output array
	int i, count[10] = { 0 };

	// Store count of occurrences in count[]
	for (i = 0; i < n; i++)
		count[(arr[i] / exp) % 10]++;

	// Change count[i] so that count[i] now contains actual
	// position of this digit in output[]
	for (i = 1; i < 10; i++)
		count[i] += count[i - 1];

	// Build the output array
	for (i = n - 1; i >= 0; i--) {
		output[count[(arr[i] / exp) % 10] - 1] = arr[i];
		count[(arr[i] / exp) % 10]--;
	}

	// Copy the output array to arr[], so that arr[] now
	// contains sorted numbers according to current digit
	for (i = 0; i < n; i++)
		arr[i] = output[i];
}
void radixsort(int a[],int size){
    int max=getmaximum(a,size);
    for(int place=0;max/place>0;place*=10){
        countSort(a,size,place);
    }
}
int getmaximum(int ar[],int size){
     int max=ar[0];
     for(int i=0;i<size;i++){
         if(ar[i]>max){
            max=ar[i];
         }
     }
     return max;
}
int main(){
    int size;
    printf("Enter the size");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("enter the element:");
        scanf("%d",&a[i]);
    }

     for(int i=0;i<size;i++){
        printf("%d\t",a[i]);
    }

}

