#include<stdio.h>
#include<stdlib.h>
int a[100];
void shellsort(int size){
  int gap,i,j;
  for(gap=size/2;gap>=0;gap/2){
   for(i=gap;i<size;i++){
    for(j=i-gap;i>=0;i-gap){
       if(a[j+gap]>a[j]){
           break;
       }
       else{
        int temp=a[j+gap];
        a[j+gap]=a[j];
        a[j]=temp;
       }
    }
   }
  }
   
}

int main(){
    int size;
    printf("Enter the size");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("enter the element:");
        scanf("%d",&a[i]);
    }
    shellsort(size);

    for(int i=0;i<size;i++){
        printf("%d\t",a[i]);
    }
}
