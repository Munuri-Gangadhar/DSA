#include<stdio.h>
#include<stdlib.h>
int a[100];
void countsort(int arr[],int size){ 
    int max=arr[0];
    int output[size];
    int i;
    for(i=0;i<size;i++){
        if(arr[i]>max){
        max=arr[i];
        }
    }
    int count[max+1];
    for(i=0;i<=max;i++){
          count[i]=0;
    }
    for(i=0;i<size;i++){
        count[arr[i]]++;
    }
    for(i=1;i<=max;i++){
         count[i]=count[i]+count[i-1]; 
    }
    for(i=size-1;i>=0;i--){
         output[count[arr[i]]-1]=arr[i];
         count[arr[i]]--;
    }
    for(i=0;i<size;i++){
        printf("%d\t",output[i]);
    }
}
int main(){
    int size;
    printf("Enter the size");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("enter the element:");
        scanf("%d",&a[i]);
    }
    countsort(a,size);
    
     
}