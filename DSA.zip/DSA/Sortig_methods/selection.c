#include<stdio.h>
#include<stdlib.h>
int arr[100],size;
void selection_sort(int a[],int len);
void print(int ar[],int len);
void swap(int a,int b);
int main(){
    int i,j,min_index;
    printf("Enter the no.of elements");
    scanf("%d",&size);
    for(i=0;i<size;i++){
       printf("Enter the element:");
       scanf("%d",&arr[i]);  
    }
    selection_sort(arr,size);
     if(size==0){
        printf("array is empty");
    }
    else{
        for(int i=0;i<size;i++){
           printf("%d\n",arr[i]);
    }
}  

}
void swap(int a,int b){
   int temp;
    temp=arr[a];
    arr[a]=arr[b];
    arr[b]=temp;
}
void selection_sort(int a[],int len){
    int size,i,j,min_index;
    for(i=0;i<len;i++){
        min_index=i;
        for(j=i+1;j<len;j++){
            if(a[j]<a[min_index]){
            min_index=j;
        }
   }
    swap(i,min_index);
    }
    //printing the sorted elements 
}

