#include<stdio.h>
#include<stdlib.h>
int arr[100],size;
void quicksort(int a[],int l,int h);
int partition(int a[],int l,int h);
void print(int ar[],int len);
int main(){
    int i,j,min_index;
    printf("Enter the no.of elements");
    scanf("%d",&size);
    for(i=0;i<size;i++){
       printf("Enter the element:");
       scanf("%d",&arr[i]);  
    }
   quicksort(arr,0,size-1);
   print(arr,size);
   
}
void quicksort(int a[],int l,int h){
    if(l<h){
     int PI;
     PI=partition(a,l,h);
     quicksort(a,l,PI-1);
     quicksort(a,PI+1,h);
    }
}
int partition(int a[],int l,int h){
    int i,j,pivot;
    pivot=a[h];
    i=l-1;
    for(j=l;j<=h;j++){
        if(a[j]<pivot){
            i++;
            int temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        }
    }
      int temp=a[i+1];
           a[i+1]=a[h];
          a[h]=temp;

   return i+1;
}

void print(int a[],int size){
    for(int i=0;i<size;i++){
       printf("%d\n",a[i]);  
    }
}




