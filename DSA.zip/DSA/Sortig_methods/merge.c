#include<stdio.h>
#include<stdlib.h>
int arr[100],size;
void mergesort(int a[],int l,int h);
void merge(int a[],int l,int mid,int h);
void printArray(int A[], int size)
{
	int i;
	for (i = 0; i < size; i++)
		printf("%d ", A[i]);
	printf("\n");
}
int main(){
   printf("enter the size of the array");
   scanf("%d",&size);
   for(int i=0;i<size;i++){
       printf("enter the data");
       scanf("%d",&arr[i]);
   }
   mergesort(arr,0,size-1); 
   //printing the sorted array
  printArray(arr, size);
   
}
void mergesort(int a[],int l,int h){
    if(l<h){
        int mid=(l+h)/2;
        mergesort(arr,l,mid);
        mergesort(arr,mid+1,h);
        merge(arr,l,mid,h);
    }
}
void merge(int a[],int l,int mid,int h){
     int i,j,k,n1,n2;
     n1=mid-l+1;n2=h-mid;
     int left[n1],r[n2];
     for(i=0;i<n1;i++){
        left[i]=a[i+l];
     }
     for(j=0;j<n2;j++){
        r[j]=a[mid+j+1];
     }
     i=0,j=0,k=l;
     while(i<n1 && j<n2){
        if(left[i]<=r[i]){
            arr[k++]=left[i];
            i++;
        }
        else{
            arr[k++]=r[j++];
        }
       
     }
     while(i<n1){
        arr[k]=left[i];
        k++;
        i++;
     }
     while(j<n2){
        arr[k]=r[j];
        k++;
        j++;
     }
    
}

