#include<stdio.h>
#include<stdlib.h>
int a[100];
void merge(int arr[],int l,int h,int mid){
    int n1,n2;
    n1=mid-l+1;
    n2=h-mid;
    int left[n1],right[n2],i;
    for(i=0;i<n1;i++){
        left[i]=arr[l+i];
    }
    for(i=0;i<n2;i++){
        right[i]=arr[mid+i+1];
    }
    i=0;
    int  j=0,k=l;
    while(i<n1 && j<n2){
        if(right[i]<=left[j]){
             arr[k++]=right[j++];
        }
        else{
             arr[k++]=left[i++];
        }
    }  
    while(i<n1){
        arr[k]=left[i];
        k++;
        i++;
    }
    while(j<n2){
        arr[k]=right[j];
        k++;
        j++;
    }
}
void mergesort(int arr[],int l,int h){
    if(l<h){
        int mid=(l+h)/2;
        mergesort(arr,l,mid);
        mergesort(arr,mid+1,h);
        merge(arr,l,h,mid);
    }
}

int main(){
    int size;
    printf("Enter the size");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("enter the element:");
        scanf("%d",&a[i]);
    }
    mergesort(a,0,size-1);
    for(int i=0;i<size;i++){
        // printf("enter the element:");
        printf("%d\t",a[i]);
    }
    
     
}