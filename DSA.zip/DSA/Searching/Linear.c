#include<stdio.h>
#include<stdlib.h>
int flag=0;
int arr[100];
int main(){
    int size;
    printf("Enter size of the array");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("Enter the element:");
        scanf("%d",&arr[i]);
    }
    int ele;
   printf("Enter searching element:");
   scanf("%d",&ele);
    for(int i=0;i<size;i++){
         if(arr[i]==ele){
         flag=i+1;
         break;
         }
     }  
   if(flag!=0){
    printf("Element is present at %d position",flag);
   }
   else{
    printf("Element is not present");
   } 
}