#include<stdio.h>
#include<stdlib.h>
int linear_search(int ar[],int size){
   int ele;
   printf("Enter searching element");
   scanf("%d",&ele);
    for(int i=0;i<size;i++){
         if(ar[i]==ele){
         return 1;
         break;
         }
         else
         return 0;  
     }  
}
int main(){
    int size;
    printf("Enter size of the array");
    scanf("%d",&size);
    int arr[size];
    for(int i=0;i<size;i++){
        printf("Enter the element:");
        scanf("%d",&arr[i]);
    }
   if(linear_search(arr,size)){
    printf("element is present");
   }
   else{
    printf("Element is not present");
   }
}