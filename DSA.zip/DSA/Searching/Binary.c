#include<stdio.h>
#include<stdlib.h>
 int arr[100],flag=0;
void Binary_search(int ar[],int l,int h){
   int ele;
   printf("Enter searching element");
   scanf("%d",&ele);
   while(l<=h){
      int mid=(l+h)/2;
      if(ar[mid]==ele){
           flag=1;
           break;
      }
      else if(ar[mid]<ele){
          l=mid+1;
      }
      else if(ar[mid]>ele){
           h=mid-1;
      }
   }
   
}
int main(){
    int size;
    printf("Enter size of the array");
    scanf("%d",&size);
    for(int i=0;i<size;i++){
        printf("Enter the element:");
        scanf("%d",&arr[i]);
    }
  Binary_search(arr,0,size-1);
  if(flag==1){
    printf("element is found");
  }
  else{
    printf("element is not found");
  }
}