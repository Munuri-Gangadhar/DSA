//Find the trace of square matrix

#include <stdio.h>
int main()
{
	int i,j,m,n,sum=0;
	printf("Enter no. of rows you want:");
	scanf("%d",&m);
	printf("Enter no. of columns you want:");
	scanf("%d",&n);
	int arr[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("Enter arr[%d][%d]:",i,j);
			scanf("%d",&arr[i][j]);
		}
	}
   
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d\040",arr[i][j]);
		}
		printf("\n");
	}
    if(m==n){
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(i==j)
				sum=sum+arr[i][j];
		}
	}
    }
	printf("Trace is %d",sum);
    
    }
