//Find the 2nd max element from array of elements
#include <stdio.h>
int main()
{
	int n,i,j,temp;
	printf("Enter no.of elements you want:");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		printf("Enter a[%d]:",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
            if(a[j]<a[i]){
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
            }
		}
	}
	printf("2nd max element is %d",a[n-2]);
}