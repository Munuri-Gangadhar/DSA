//Find the sum of elements of 2D array
#include <stdio.h>
int main()
{
	int m,n,i,j,sum=0;
	printf("Enter no. of rows:");
	scanf("%d",&m);
	printf("Enter no. of columns:");
	scanf("%d",&n);
	int a[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("Enter a[%d][%d]",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			sum=sum+a[i][j];
		}
	}
	printf("Sum is %d",sum);
}