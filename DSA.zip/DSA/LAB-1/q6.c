//Store and retrive student information using structures
#include <stdio.h>
int main()
{
	int n,i;
	printf("Enter no. of students:");
	scanf("%d",&n);
	struct student
	{
		int id;
		char name[20];
		float cgpa;
		char village[20];
	}s[20];
	for(i=0;i<n;i++)
	{
		printf("Enter student%d id:",i+1);
		scanf("%d",&s[i].id);
		printf("Enter student%d name:",i+1);
		scanf("%s",&s[i].name);
		printf("Enter student%d cgpa:",i+1);
		scanf("%f",&s[i].cgpa);
		printf("Enter student%d village:",i+1);
		scanf("%s",&s[i].village);
	}
	for(i=0;i<n;i++)
	{
		printf("student%d id:%d\n",i+1,s[i].id);
		printf("student%d name:%s\n",i+1,s[i].name);
		printf("student%d cgpa:%f\n",i+1,s[i].cgpa);
		printf("student%d village:%s\n",i+1,s[i].village);
	}
}
    