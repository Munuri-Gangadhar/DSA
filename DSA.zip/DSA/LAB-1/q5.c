//Bubble sorting
#include <stdio.h>
void main()
{
	int i,j,n,temp;
	printf("Enter no. of terms:\n");
	scanf("%d",&n);
	int a[n];
	printf("Enter Elements");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
    {
        for(j=0;j<n-i;j++)
        {
            if(a[j]>a[j+1])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
    printf("sorted arrays:\n");
    for(i=0;i<n;i++)
    {
    	printf("%d\n",a[i]);
	}
}