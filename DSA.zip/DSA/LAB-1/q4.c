//Find the factorial using recursion
#include <stdio.h>
int fact(int x);
int main()
{
	int n;
	printf("Enter a number:");
	scanf("%d",&n);
	printf("Factorial of %d is %d\n",n,fact(n));
    int m,i;
	printf("Enter no. of elements:");
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		printf("%d",fib(i));
	}
}
int fact(int x)
{
	if(x==0)
		return 1;
	else
		return (x*fact(x-1));
}
int fib(int m)
{
	if(m==0)
		return 0;
	else if(m==1)
		return 1;
	else
		return fib(m-1)+fib(m-2);
}