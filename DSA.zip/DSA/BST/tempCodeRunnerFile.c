#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *left,*right;
}*root=NULL,*p,*temp;
struct node *create(int key){
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=key;
    temp->right=NULL;
    temp->left=NULL;
    return temp;
}
struct node *insert(struct node *root,int key){
    if(root==NULL){
        return create(key);
    }
    else if(key>root->data){
           root->right=insert(root->right,key);
    }
    else if(key<root->data){
             root->left=insert(root->left,key);
    }
    return root;
}
void inorder(struct node *NROOT){
  if(NROOT!=NULL){
    inorder(NROOT->left);
     printf("%d\t",NROOT->data);
    inorder(NROOT->right);
  }
}
void preorder(struct node *NROOT){
    if(NROOT!=NULL){
        printf("%d\t",NROOT->data);
        preorder(NROOT->left);
        preoder(NROOT->right);
    }
}
void postorder(struct node *NROOT){
    if(NROOT!=NULL){
        postorder(NROOT->left);
        postorder(NROOT->right);
        printf("%d\t",NROOT->data);
    }
}
struct node *minvalueBST(struct node *NR){
    p=NR;
    while(p!=NULL && p->left!=NULL){
        p=p->left;
    }
    return p;
}
struct node *delete(struct node *root,int value){
    if(root==NULL){
        return root;
    }
    if(value>root->data){
        root->right=delete(root->right,value);
    }
    else if(value<root->data){
        root->left=delete(root->left,value);
    }
    else{
        if(root->left==NULL){
             temp=root->left;
             free(root);
             return temp;
        }
        if(root->right==NULL){
            temp=root->right;
            free(root);
            return temp;
        }
        temp=minvalueBST(root->right);
        root->data=temp->data;
        root->right=delete(root->right,temp->data);
    }
    return root;
}
struct node *search(struct node*root,int key){
    if(root->data==key){
         printf("Element is found");
    }
    else if(key>root->data){
        root->right=search(root->right,key);
    }
    else if(key<root->data){
        root->left=search(root->left,key);
    }
    else{
        printf("Enter value is not present");
    }
}
int node_num(struct node*NROOT){
    if(NROOT==NULL){
        return 0;
    }
    else{
         return node_num(NROOT->left)+node_num(NROOT->right)+1;
    }
}
int inter_node(struct node*NROOT){
    if(NROOT==NULL){
        return 0;
    }
    if(NROOT->left==NULL && NROOT->right ==NULL){
        return 0;
    }
    else{
        return inter_node(NROOT->left)+inter_node(NROOT->right)+1;
    }
}
int exter_node(struct node *NROOT){
    if(NROOT==NULL){
        return 0;
    }
    if(NROOT->left==NULL && NROOT->right==NULL){
        return 1;
    }
    else{
        return exter_node(NROOT->right)+exter_node(NROOT->left);
    }
}
int height(struct node *NROOT){
    if(NROOT==NULL){
        return 0;
    }
    else{
        int LH=height(NROOT->left);
        int RH=height(NROOT->right);
        if(LH>RH){
            return LH+1;
        }
        else{
            return RH+1;
        }
    }
}
int main(){
    //  printf("1.Insertion\n2.Inorder\n3.Preorder\n4.Postorder\n5.Delete a node\n6.Searching the value\n7.No.of Nodes\n8.Internal nodes\n9.External nodes\n10.Height");
     while(1){
        int op;
        printf("\n1.Insertion\n2.Inorder\n3.Preorder\n4.Postorder\n5.Delete a node\n6.Searching the value\n7.No.of Nodes\n8.Internal nodes\n9.External nodes\n10.Height\n");
        printf("\nEnter the option:");
        scanf("%d",&op);
        int val;
        switch(op){
            case 1:
            printf("Enter the value:");
            scanf("%d",&val);
            root=insert(root,val);
            break;
            case 2:
            inorder(root);
            break;
            case 3:
            preorder(root);
            break;
            case 4:
            postorder(root);
            break;
            case 5: 
            inorder(root);
            printf("\nEnter above any element to delete");
            scanf("%d",&val);
            delete(root,val);
            break;
            case 6:
            inorder(root);
            printf("\nEnter the value to search");
            scanf("%d",&val);
            search(root,val);
            break;
            case 7:
            printf("\nNo.of nodes is:%d",node_num(root));
            break;
            case 8:
            printf("\nNo.of internal nodes%d:",inter_node(root));
            break;
            case 9:
            printf("\nNo.of external nodes%d:",exter_node(root));
            break;
            case 10:
            printf("Height of tree is:%d",height(root));
            break;
            default:
            exit(0);
            break;
        }
     } 
}