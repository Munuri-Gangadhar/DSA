#include<stdio.h>
#include<stdlib.h>
int main(){
   
    
}