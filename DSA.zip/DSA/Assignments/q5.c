#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*start=NULL,*temp,*p,*start1,*start2;
struct node *creation(struct node *p);
struct node *sort(struct node *l);
int main(){ 
   start1=creation(start1);
   start2=creation(start2);

   //sorting the two linked lists
   start1=sort(start1);
   start2=sort(start2);
   //concentenation of  two linked list
   p=start1;
   while(p->next!=NULL){
      p=p->next;
   }
   p->next=start2;
   //printing the concentenated two linked list
   p=start1;
   while(p!=NULL){
      printf("%d\n",p->data);
      p=p->next;
   }
  
}
struct node *creation(struct node *start){
    int n,i;
    printf("Enter the no.of nodes");
    scanf("%d",&n);
    for(i=0;i<n;i++){
    int m;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data");
    scanf("%d",&m);
    temp->data=m;
    temp->next=NULL;
    if(start==NULL){
       start=temp;
       p=temp;
    }
    else{
       p->next=temp;
       p=temp;
      }
    }
    return start;
}
struct node *sort(struct node *l){
 if(l==NULL){
    printf("list is empty");
   }
   else{
    struct node *temp1,*temp2,*x;
     for(temp1=l;temp1!=NULL;temp1=temp1->next){
        for(temp2=l->next;temp2!=NULL;temp2=temp2->next){
            if(temp1->data>temp2->data){
                 x=temp1;
                 temp2=temp1;
                 temp2=x;
            }
        }
     }

   }
   return l;
}

 

