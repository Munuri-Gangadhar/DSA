#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*start,*p,*temp,*ll;
struct node*create(struct node *start);
struct node*r_dup(struct node *k);
int main(){
    ll=create(ll);
    //removing the duplicates from the linked list
    ll=r_dup(ll);
    p=ll;
    while(p!=NULL){
        printf("%D",p->data);
        p=p->next;
    }
}
struct node*create(struct node *start){
      int n,m;
    printf("Enter no.of nodes:");
    scanf("%d",&n);
   for(int i=0;i<n;i++){
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter data for %d node:",i+1);
    scanf("%d",&m);
    temp->next=NULL;
    temp->data=m;
    if(start==NULL){
        start=temp;
        p=temp;
    }
    else{
        p->next=temp;
        p=temp;
    }
   }
   return start;
}
struct node *r_dup(struct node *k){
    struct node *temp1=NULL,*temp2=NULL;
     if(k==NULL){
        printf("list is empty");
     }
     else{
        for(temp1=k;temp1->next!=NULL;temp1=temp1->next){
            for(temp2=temp1->next;temp2->next!=NULL;temp2=temp2->next){
                if(temp1->data==temp2->data){
                    temp=temp2->next;
                    temp2->next=temp2->next->next;
                    free(temp);
                }
            }
        }
     }
     return k;
}