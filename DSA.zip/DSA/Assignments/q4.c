#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*node,*p,*temp,*newnode;
struct node*create(struct node *start){
      int n,m;
    printf("Enter no.of nodes:");
    scanf("%d",&n);
   for(int i=0;i<n;i++){
    temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter data for %d node:",i+1);
    scanf("%d",&m);
    temp->next=NULL;
    temp->data=m;
    if(start==NULL){
        start=temp;
        p=temp;
    }
    else{
        p->next=temp;
        p=temp;
    }
   }
   return start;
}
int main(){
    node=create(node);
    //spliting  of the nodes;
    p=node;
    int count=0;
    if(p==NULL){
        printf("list is empty");
    }
    else{
      while(p!=NULL){
        p=p->next;
        count++;
      }
    }
    p=node;
    int merge=count/2; 
    for(int i=0;i<merge-1;i++){
        p=p->next;
    }
    newnode=p->next;
    p->next=NULL;
    //printing the two nodes
    struct node *p1=NULL,*p2=NULL;
    printf("\nfirst part data is:\n");
    p1=node;
    while(p1!=NULL){
        printf("%d\n",p1->data);
        p1=p1->next;
    }
    printf("\nSecond part data is:\n");
    p2=newnode;
    while(p2!=NULL){
        printf("%d\n",p2->data);
        p2=p2->next;
    }
  
    
}
