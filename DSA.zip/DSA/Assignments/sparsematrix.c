#include<stdio.h>
#include<stdlib.h>
struct node{
    int row;
    int col;
    int value;
    struct node *next;
}*start=NULL,*temp,*p,*l;
struct node *create(int row,int col,int value,struct node *start);
int main(){
    int arr[5][6];
    int i,j;
    for(i=0;i<5;i++){
        for(j=0;j<6;j++){
            printf("Enter the element at row %d and col%d:",i,j);
            scanf("%d",&arr[i][j]);
        }
    }    
    for(i=0;i<5;i++){
        for(j=0;j<6;j++){
            printf("%d\t",arr[i][j]);
        }
        printf("\n");
    } 
    //checking the array which consists whether non-zero elements are present
    for(i=0;i<5;i++){
        for(j=0;j<6;j++){
            if(arr[i][j]!=0){
              l=create(i,j,arr[i][j],l); 
            }
        }
    }
    printf("\n");
    
    p=l;
    if(p==NULL){
        printf("non-zero elements are present");
    }
    else{
        while(p!=NULL){
            printf("%d\n",p->value);
            p=p->next;
        }
    }
}
struct node *create(int row,int col,int value,struct node*start){
    temp=(struct node*)malloc(sizeof(struct node));
    temp->row=row;
    temp->col=col;
    temp->value=value;
    if(start==NULL){
         start=temp;
         p=temp;
    }
    else{
        p->next=temp;
        p=temp;
    }
    return start;

}