#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*ll1,*ll2,*temp,*p,*ll3;
struct node *create(struct node *k){
    int n,m;
    printf("enter no.of nodes you want");
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        temp=(struct node*)malloc(sizeof(struct node));
        printf("Enter the data");
        scanf("%d",&m);
        temp->data=m;
        temp->next=NULL;
        if(k==NULL){
            k=temp;
            p=temp;
        }
        else{
           p->next=temp;
           p=temp; 
        }
    }
    return k;
}
struct node *third(struct node *k,int data){
    temp=(struct node*)malloc(sizeof(struct node));
    temp->next=NULL;
    temp->data=data;
    if(k==NULL){
        k=temp;
        p=temp;
    }
    else{
        p->next=temp;
        p=temp;
    }
    return k;
}
int main(){
    ll1=create(ll1);
    ll2=create(ll2);
    int c=0;
    while(ll1!=NULL|| ll2!=NULL||c){
        int sum=0;
       if(ll1!=NULL){
          sum=sum+ll1->data;
          ll1=ll1->next;
       }
       if(ll2!=NULL){
          sum=sum+ll2->data;
          ll2=ll2->next;
       }
       sum=sum+c;
       c=sum/10;
       ll3=third(ll3,sum%10);
    }
    p=ll3;
    while(p!=NULL){
        printf("%d",p->data);
        p=p->next;
    }

   return 0;
}