#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*reversing the string using push and pop opertaion*/
int main(){
    printf("enter the string:");
    char s[100];
    scanf("%s",&s);
    int size=strlen(s);
    int arr[size],top=-1,i;
    char reverse[size];
    //pushing  the character in the stack
    for(i=0;i<size;i++){
        top=top+1;
        arr[top]=s[i];
    }
    //pop the character in the stack
    for(i=0;i<size;i++){
         reverse[i]=arr[top];
         top=top-1;
    }
    reverse[i]='\0';   

    printf("\nThe actual string:%s\n",s);
    printf("\nReversed String is:%s",reverse);

    
}