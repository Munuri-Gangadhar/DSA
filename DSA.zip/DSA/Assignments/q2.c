#include<stdio.h>
#include<stdlib.h>
struct node{
    int coeff;
    int expo;
    struct node*next;
}*res,*temp,*p,*third=NULL;
struct node *create(struct node *k);
void polyadd(struct node*first,struct node *second);
struct node *result(struct node*k,int coeff,int expo);
int main(){
    int sum;
    struct node *p1=NULL;
    struct node *p2=NULL;
    p1=create(p1);
    p2=create(p2); 
    polyadd(p1,p2);

    
}
struct node *create(struct node *k){
    int n,m;
    printf("Enter no.of nodes:");
    scanf("%d",&m);
    for(int i=0;i<m;i++){   
           temp=(struct node*)malloc(sizeof(struct node));
            int coeff,expo;
            printf("enter the coeff:");
            scanf("%d",&coeff);
            printf("enter  the exponent:");
            scanf("%d",&expo);
            temp->coeff=coeff;
            temp->expo=expo;
            temp->next=NULL;
            if(k==NULL){
                k=temp;
                p=temp;
            }
            else{
                p->next=temp;
                p=temp;
            }
    }
    return k;

}
void polyadd(struct node*first,struct node *second){
    struct node *p1=first;
    struct node *p2=second;
    while(p1!=NULL && p2!=NULL){
        if(p1->expo == p2->expo){
           third=result(third,p1->coeff+p2->coeff,p1->expo);
           p1=p1->next;
           p2=p2->next;
        }
        else if(p1->expo>p2->expo){
            third=result(third,p1->coeff,p1->expo);
            p1=p1->next;

        }
        else{
            third=result(third,p2->coeff,p2->expo);
            p2=p2->next;
        }
}
     while(p1!=NULL){
        third=result(third,p1->coeff,p1->expo);
        p1=p1->next;
     }
     while(p2!=NULL){
        third=result(third,p2->coeff,p2->expo);
        p2=p2->next;
     }
    p=third;
    while(p!=NULL){
        printf("coeffient:%d\t",p->coeff);
        printf("exponent:%d\n",p->expo);

        p=p->next;
    }
}
struct node *result(struct node*k,int coeff,int expo){
    temp=(struct node*)malloc(sizeof(struct node));
    temp->coeff=coeff;
    temp->expo=expo;
    temp->next=NULL;
    if(k==NULL){
        k=temp;
        p=temp;
    }
    else{
        p->next=temp;
        p=temp;
    }
    return k;
}
